#!/bin/sh
chmod +x pkusoftwareanalysislab2
./pkusoftwareanalysislab2 $1